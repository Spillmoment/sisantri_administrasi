<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Regencie extends Model
{
    // protected $table = '';
    
}
