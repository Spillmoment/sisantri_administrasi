@extends('layout.template.main')

@section('title', 'Data Kategori')
@section('container')
@endsection