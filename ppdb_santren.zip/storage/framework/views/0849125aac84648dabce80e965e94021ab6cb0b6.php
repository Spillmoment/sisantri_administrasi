<?php $__env->startSection('container'); ?>
<form id="example-advanced-form" action="/daftar/create-step1" method="post">
    <?php echo csrf_field(); ?>
    <h3>User</h3>
    <fieldset class="form-input">
        <h4>Daftar</h4>

        <label for="userName">Username *</label>
        
        <input type="text" value="<?php echo e(session()->get('user.username')); ?>" class="form-control required"  name="username">
        
        <label for="email" class="mt-3">Email *</label>
        
        <input type="email" value="<?php echo e(session()->get('user.email')); ?>" class="form-control required"  name="email">
        
        <label for="password" class="mt-3">Password *</label>
        
        <input type="password"  value="<?php echo e(session()->get('user.password_hash')); ?>" class="form-control required" name="password_hash"/>
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Next</button>
    </fieldset>

</form>		

    
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.form_wizard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/register/create-step1.blade.php ENDPATH**/ ?>