<?php $__env->startSection('container'); ?>
<form id="example-advanced-form" action="/daftar/create-step2" method="post">
    <?php echo csrf_field(); ?>
    <h3>Wali</h3>
    <fieldset class="form-input">
        <h4>Santri</h4>

        <label for="ayah">nama ayah *</label>
        <input type="text" value="<?php echo e(session()->get('wali_santri.nama_suami')); ?>" class="form-control required"  name="nama_suami">
        
        <label for="tglAyah" class="mt-3">Tanggal lahir</label>
        <input type="date" value="<?php echo e(session()->get('wali_santri.tgl_suami')); ?>" class="form-control required"  name="tgl_suami">

        <label for="pendidikanAyah" class="mt-3">Pendidikan terakhir</label>
        <input type="text" value="<?php echo e(session()->get('wali_santri.pendidikan_suami')); ?>" class="form-control required"  name="pendidikan_suami">
        
        <label for="pekerjaanAyah" class="mt-3">Pekerjaan </label>
        <input type="text" value="<?php echo e(session()->get('wali_santri.pekerjaan_suami')); ?>" class="form-control required"  name="pekerjaan_suami">

        <label for="penghasilanAyah" class="mt-3">Penghasilan</label>
        <input type="number" value="<?php echo e(session()->get('wali_santri.penghasilan_suami')); ?>" class="form-control required"  name="penghasilan_suami">


        <label for="ibu" class="mt-3">nama ibu *</label>
        <input type="text" value="<?php echo e(session()->get('wali_santri.nama_istri')); ?>" class="form-control required"  name="nama_istri">

        <label for="tglIbu" class="mt-3">Tanggal lahir</label>
        <input type="date" value="<?php echo e(session()->get('wali_santri.tgl_istri')); ?>" class="form-control required"  name="tgl_istri">

        <label for="pendidikanIbu" class="mt-3">Pendidikan terakhir</label>
        <input type="text" value="<?php echo e(session()->get('wali_santri.pendidikan_istri')); ?>" class="form-control required"  name="pendidikan_istri">
        
        <label for="pekerjaanIbu" class="mt-3">Pekerjaan </label>
        <input type="text" value="<?php echo e(session()->get('wali_santri.pekerjaan_istri')); ?>" class="form-control required"  name="pekerjaan_istri">

        <label for="penghasilanIbu" class="mt-3">Penghasilan</label>
        <input type="number" value="<?php echo e(session()->get('wali_santri.penghasilan_istri')); ?>" class="form-control required"  name="penghasilan_istri">

        

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Next</button>
    </fieldset>

</form>	

    
<?php $__env->stopSection(); ?>

<script>
    function showDiv(divId, element)
    {
        document.getElementById(divId).style.display = element.value == 'ULYA PLUS RAUDLATUL MALIKIYAH' ? 'block' : 'none';
    }
</script>
<?php echo $__env->make('layout.form_wizard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/register/create-step2.blade.php ENDPATH**/ ?>