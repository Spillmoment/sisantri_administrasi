<?php $__env->startSection('container'); ?>
<form id="example-advanced-form" action="/daftar/create-step3" method="post">
    <?php echo csrf_field(); ?>
    <h3>Account</h3>
    <fieldset class="form-input">
        <h4>Santri</h4>
        <label for="confirm">Tempat lahirrrr *</label>
        <input type="text" value="<?php echo e(session()->get('santri.tempat_lahir')); ?>" class="form-control required"  name="tempat_lahir">
        
        <label for="userName">Nama *</label>
        <input type="text" value="<?php echo e(session()->get('santri.nama')); ?>" class="form-control required"  name="nama">
        
        <label for="confirm" class="mt-3">NIS *</label>
        <input type="text"  value="<?php echo e(session()->get('santri.nis')); ?>" class="form-control required" name="nis"/>

        <label for="confirm" class="mt-3">Wilayah *</label>
        <select name="id_wilayah" class="form-control form-control form-control-alternative">
            <?php $__currentLoopData = $wilayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value=<?php echo e($item->id_wilayah); ?>><?php echo e($item->nama_wilayah); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="confirm" class="mt-3">Pendidikan Formal</label>
        <select name="kd_jp_formal" class="form-control form-control form-control-alternative">
            <?php $__currentLoopData = $pen_formal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($item->kd_jp_formal); ?>" <?php if(isset($santri->kd_jp_formal) && $santri->kd_jp_formal == session()->get('santri.kd_jp_formal')): ?>
                selected="selected"
              <?php endif; ?>><?php echo e($item->jenjang_pendidikan); ?></option>
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="confirm" class="mt-3">Pendidikan Diniah</label>
        <select name="kd_jp_diniah" class="form-control form-control form-control-alternative">
            <?php $__currentLoopData = $pen_diniah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value=<?php echo e($item->kd_jp_diniah); ?>><?php echo e($item->jenjang_pendidikan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="confirm" class="mt-3">Jurusan</label>
        <select name="kd_jurusan" class="form-control form-control form-control-alternative">
            <?php $__currentLoopData = $pen_jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value=<?php echo e($item->kd_jurusan); ?>><?php echo e($item->nm_jurusan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="confirm" class="mt-3">Provinsi</label>
        <select name="provinces_id" class="province form-control form-control form-control-alternative">
            <option value="0" disabled="true" selected="true">-Provinsi-</option>
            <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value=<?php echo e($item->id); ?>><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="confirm" class="mt-3">Kabupaten</label>
        <select name="regencies_id" class="regencie form-control form-control form-control-alternative">
            <option value="0" disabled="true" selected="true">-Kabupaten-</option>
        </select>

        <label for="confirm" class="mt-3">Kecamatan</label>
        <select name="districts_id" class="district form-control form-control form-control-alternative">
            <option value="0" disabled="true" selected="true">-Kecamatan-</option>
        </select>

        <label for="confirm" class="mt-3">Desa</label>
        <select name="village_id" class="village form-control form-control form-control-alternative">
            <option value="0" disabled="true" selected="true">-Desa-</option>
        </select>

        

        

        <label for="confirm">Tanggal lahir *</label>
        <input type="date" value="<?php echo e(session()->get('santri.tgl')); ?>" class="form-control required"  name="tgl">
        
        <label for="confirm" class="mt-3">Jenis kelamin *</label><br>
        <label class="radio-inline"><input type="radio" name="jenis_kelamin" value="L" <?php echo e((isset($santri['jenis_kelamin']) && $santri['jenis_kelamin'] == 'L') ? "checked" : ""); ?>> Laki-laki</label>
        <label class="radio-inline"><input type="radio" name="jenis_kelamin" value="P" <?php echo e((isset($santri['jenis_kelamin']) && $santri['jenis_kelamin'] == 'P') ? "checked" : ""); ?>> Perempuan</label><br>
        
        <label for="tempatLahir">Alamat Lengkap*</label>
        <textarea name="alamat" id="alamat" cols="30" rows="10" class="form-control"><?php echo e(session()->get('santri.alamat')); ?></textarea>

        <label for="confirm">Email </label>
        <input type="email" value="<?php echo e(session()->get('santri.email')); ?>" class="form-control"  name="email">

        <label for="confirm">Asal Sekolah *</label>
        <input type="text" value="<?php echo e(session()->get('santri.asal_sekolah')); ?>" class="form-control required"  name="asal_sekolah">

        <label for="confirm">No. Telephone</label>
        <input type="text" value="<?php echo e(session()->get('santri.telephone')); ?>" class="form-control required"  name="telephone">
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Next</button>
    </fieldset>

</form>		



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.form_wizard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/register/create-step3.blade.php ENDPATH**/ ?>