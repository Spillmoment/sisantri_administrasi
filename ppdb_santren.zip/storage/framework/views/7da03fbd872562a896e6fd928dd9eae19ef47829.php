<!DOCTYPE html>
<html lang="en">
<head>
<title> Wizard Form with Validation - Responsive</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="html.design">
<!-- description -->
<meta name="description" content="Wizard Form with Validation - Responsive">
<link rel="shortcut icon" href="<?php echo e(url('wizard_form/images/favicon.ico')); ?>">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo e(url('wizard_form/css/bootstrap.min.css')); ?>">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.9/css/all.css">
<!-- Fonts and icons -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700" rel="stylesheet"> 
<!-- Reset CSS -->
<link rel="stylesheet" href="<?php echo e(url('wizard_form/css/reset.css')); ?>">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo e(url('wizard_form/css/style.css')); ?>">
<!-- Responsive  CSS -->
<link rel="stylesheet" href="<?php echo e(url('wizard_form/css/responsive.css')); ?>">
</head>
<body>

<div class="wizard-main">
	<div id="particles-js"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="title-wb">Wizard Form with Validation</h2>
			</div>
		</div>
		<div class="row">
			
			<div class="col-lg-8 login-sec">
				<div class="login-sec-bg">
					<h2 class="text-center">Account Information</h2>
						<?php echo $__env->yieldContent('container'); ?>
					
				</div>
			</div>			
		</div>
		<div class="row">
			<div class="col-lg-12">
				<p class="copyright text-center">All Rights Reserved. &copy; 2018 <a href="#">Wizard Form with Validation</a> Design By : 
					<a href="https://html.design/">html design</a>
				</p>
			</div>
		</div>
	</div>
</div>

<!-- jquery latest version -->
<script src="<?php echo e(url('wizard_form/js/jquery.min.js')); ?>"></script>
<!-- popper.min.js -->
<script src="<?php echo e(url('wizard_form/js/popper.min.js')); ?>"></script>    
<!-- bootstrap js -->
<script src="<?php echo e(url('wizard_form/js/bootstrap.min.js')); ?>"></script>
<!-- jquery.steps js -->
<script src='https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js'></script>
<script src="<?php echo e(url('wizard_form/js/jquery.steps.js')); ?>"></script>
<!-- particles js -->
<script src="<?php echo e(url('wizard_form/js/particles.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function() {
		particlesJS("particles-js", 
			{
			  "particles": {
				"number": {
				  "value": 160,
				  "density": {
					"enable": true,
					"value_area": 800
				  }
				},
				"color": {
				  "value": "#ffffff"
				},
				"shape": {
				  "type": "circle",
				  "stroke": {
					"width": 0,
					"color": "#000000"
				  },
				  "polygon": {
					"nb_sides": 5
				  },
				  "image": {
					"src": "img/github.svg",
					"width": 100,
					"height": 100
				  }
				},
				"opacity": {
				  "value": 1,
				  "random": true,
				  "anim": {
					"enable": true,
					"speed": 1,
					"opacity_min": 0,
					"sync": false
				  }
				},
				"size": {
				  "value": 3,
				  "random": true,
				  "anim": {
					"enable": false,
					"speed": 4,
					"size_min": 0.3,
					"sync": false
				  }
				},
				"line_linked": {
				  "enable": false,
				  "distance": 150,
				  "color": "#ffffff",
				  "opacity": 0.4,
				  "width": 1
				},
				"move": {
				  "enable": true,
				  "speed": 1,
				  "direction": "none",
				  "random": true,
				  "straight": false,
				  "out_mode": "out",
				  "bounce": false,
				  "attract": {
					"enable": false,
					"rotateX": 600,
					"rotateY": 600
				  }
				}
			  },
			  "interactivity": {
				"detect_on": "canvas",
				"events": {
				  "onhover": {
					"enable": true,
					"mode": "bubble"
				  },
				  "onclick": {
					"enable": true,
					"mode": "repulse"
				  },
				  "resize": true
				},
				"modes": {
				  "grab": {
					"distance": 400,
					"line_linked": {
					  "opacity": 1
					}
				  },
				  "bubble": {
					"distance": 250,
					"size": 0,
					"duration": 2,
					"opacity": 0,
					"speed": 3
				  },
				  "repulse": {
					"distance": 400,
					"duration": 0.4
				  },
				  "push": {
					"particles_nb": 4
				  },
				  "remove": {
					"particles_nb": 2
				  }
				}
			  },
			  "retina_detect": true
			}
    	);
	});
</script>

<script>
    $(document).ready(function () {
       $(document).on('change','.province',function() {
           let provId = $(this).val();

					 let div = $(this).parent();	
					 let add = " ";

					 $.ajax({
						 type:'get',
						 url:'<?php echo e(route('getregencies')); ?>',
						 data:{'id':provId},
						 success:function(data) {
							//  add += '<option value="0" selected disabled>-Kabupaten-</option>';
							 for(let i=0; i<data.length; i++){
								 add += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
							 }

							 div.find('.regencie').html(" ");
							 div.find('.regencie').append(add);
						 },
						 error:function() {
							 
						 }
					 });
       });

       $(document).on('change','.regencie',function() {
           let regencyId = $(this).val();

					 let div = $(this).parent();	
					 let add = " ";

					 $.ajax({
						 type:'get',
						 url:'<?php echo e(route('getdistricts')); ?>',
						 data:{'id':regencyId},
						 success:function(data) {
							 for(let i=0; i<data.length; i++){
								 add += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
							 }

							 div.find('.district').html(" ");
							 div.find('.district').append(add);
						 },
						 error:function() {
							 
						 }
					 });
       }); 
       
			 $(document).on('change','.district',function() {
           let districtId = $(this).val();

					 let div = $(this).parent();	
					 let add = " ";

					 $.ajax({
						 type:'get',
						 url:'<?php echo e(route('getvillages')); ?>',
						 data:{'id':districtId},
						 success:function(data) {
							 for(let i=0; i<data.length; i++){
								 add += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
							 }

							 div.find('.village').html(" ");
							 div.find('.village').append(add);
						 },
						 error:function() {
							 
						 }
					 });
       }); 

    });
</script>



</body>
</html><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/layout/form_wizard/main.blade.php ENDPATH**/ ?>