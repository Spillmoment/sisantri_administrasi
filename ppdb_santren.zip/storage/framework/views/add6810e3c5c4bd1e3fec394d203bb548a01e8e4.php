<?php $__env->startSection('container'); ?>
<form id="example-advanced-form" action="/daftar/store" method="post">
    <?php echo csrf_field(); ?>
    <h3>Review</h3>
    <fieldset class="form-input">
        <table class="table">
            <tr>
                <td>Product Name:</td>
                <td><strong><?php echo e($santri['nama']); ?></strong></td>
            </tr>
            <tr>
                <td>santri</td>
                <td><strong><?php echo e($santri['nis']); ?></strong></td>
            </tr>
            <tr>
                <td>Nama Ayah</td>
                <td><strong><?php echo e($wali_santri['nama_suami']); ?></strong></td>
            </tr>
            <tr>
                <td>Nama Ibu</td>
                <td><strong><?php echo e($wali_santri['nama_istri']); ?></strong></td>
            </tr>
            <tr>
                <td>Foto Santri:</td>
                <td><strong><img alt="Foto Santri" src="/uploads/santri_foto/<?php echo e($santri->foto); ?>"/></strong></td>
            </tr>
        </table>
    </fieldset>
    <a type="button" href="/daftar/create-step1" class="btn btn-warning">Back to Step 1</a>
    <a type="button" href="/daftar/create-step2" class="btn btn-warning">Back to Step 2</a>
    <button type="submit" class="btn btn-primary">Create</button>
</form>	

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.form_wizard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/register/create-step4.blade.php ENDPATH**/ ?>