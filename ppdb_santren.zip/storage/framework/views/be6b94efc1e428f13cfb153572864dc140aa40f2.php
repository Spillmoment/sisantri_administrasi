<?php $__env->startSection('container'); ?>
<h1>Simpan File</h1>
    <hr>
    <?php if(isset($santri->foto)): ?>
    Foto Santri:
    <img alt="Foto Santri" src="/uploads/santri_foto/<?php echo e($santri->foto); ?>" width="250px" height="auto"/>
    <?php endif; ?>
    <?php if(isset($santri->foto)): ?>
    Foto Santri:
    <img alt="Foto Santri" src="/uploads/santri_foto_kk/<?php echo e($santri->foto_kk); ?>" width="250px" height="auto"/>
    <?php endif; ?>

    <form action="/daftar/create-file" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h3>Upload File Santri</h3><br/><br/>

        <div class="form-group">
            <input type="file" <?php echo e((!empty($santri->foto)) ? "disabled" : ''); ?> class="form-control-file" name="foto" id="foto" aria-describedby="fileHelp">
            <small id="fileHelp" class="form-text text-muted">Please upload a valid image file. Size of image should not be more than 2MB.</small>
        </div>
        <div class="form-group">
            <input type="file" <?php echo e((!empty($santri->foto_kk)) ? "disabled" : ''); ?> class="form-control-file" name="foto_kk" id="foto_kk" aria-describedby="fileHelp">
            <small id="fileHelp" class="form-text text-muted">Please upload a valid image file. Size of image should not be more than 2MB.</small>
        </div>
        <button type="submit" class="btn btn-primary">Lanjut</button>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </form><br/>
    
    <?php if(isset($santri->foto)): ?>
    <form action="/daftar/remove-foto" method="post">
        <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-danger">Hapus Foto</button>
    </form>
    <?php endif; ?>

    <?php if(isset($santri->foto_kk)): ?>
    <form action="/daftar/remove-fotokk" method="post">
        <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-danger">Hapus Foto KK</button>
    </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.form_wizard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/register/create-file.blade.php ENDPATH**/ ?>