<?php $__env->startSection('title', 'Data Kategori'); ?>
<?php $__env->startSection('container'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gunawan/Project/ppdb_santren/resources/views/welcome.blade.php ENDPATH**/ ?>